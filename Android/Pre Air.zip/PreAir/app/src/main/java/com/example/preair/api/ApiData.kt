package com.example.preair.api

interface ApiData {
}